import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:tracky/widget/button_widget.dart';
import 'package:tracky/widget/navigation_drawer_widget.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SystemChrome.setPreferredOrientations([
    DeviceOrientation.portraitUp,
    DeviceOrientation.portraitDown,
  ]);

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  static final String title = 'Tracky';

  // Define existing profiles here (replace with your actual list of profiles)
  final List<String> existingProfiles = ['Profile A', 'Profile B', 'Profile C'];

  @override
  Widget build(BuildContext context) => MaterialApp(
        debugShowCheckedModeBanner: false,
        title: title,
        theme: ThemeData(primarySwatch: Colors.blue),
        home: MainPage(existingProfiles: existingProfiles),
      );
}

class MainPage extends StatefulWidget {
  final List<String> existingProfiles;

  MainPage({required this.existingProfiles});

  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  @override
  Widget build(BuildContext context) => Scaffold(
        drawer:
            NavigationDrawerWidget(existingProfiles: widget.existingProfiles),
        appBar: AppBar(
          title: Text(MyApp.title),
        ),
        body: Builder(
          builder: (context) => Container(
            alignment: Alignment.center,
            padding: EdgeInsets.symmetric(horizontal: 32),
            child: ButtonWidget(
              icon: Icons.open_in_new,
              text: 'Open Drawer',
              onClicked: () {
                Scaffold.of(context).openDrawer();
              },
            ),
          ),
        ),
      );
}
