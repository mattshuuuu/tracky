import 'package:flutter/material.dart';

class AboutUsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text('About Us'),
      centerTitle: true,
      backgroundColor: Colors.red,
    ),
  );
}