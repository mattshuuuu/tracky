import 'package:flutter/material.dart';

class PaymentsPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text('Payments'),
      centerTitle: true,
      backgroundColor: Colors.red,
    ),
  );
}