import 'package:flutter/material.dart';

class DashboardPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(
      title: Text('Dashboard'),
      centerTitle: true,
      backgroundColor: Colors.red,
    ),
  );
}