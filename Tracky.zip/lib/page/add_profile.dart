import 'package:flutter/material.dart';

class AddProfilePage extends StatefulWidget {
  final List<String> existingProfiles;

  AddProfilePage({required this.existingProfiles});

  @override
  _AddProfilePageState createState() => _AddProfilePageState();
}

class _AddProfilePageState extends State<AddProfilePage> {
  final TextEditingController _nameController = TextEditingController();
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  String? _validateProfileName(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter a profile name.';
    }
    if (widget.existingProfiles.contains(value)) {
      return 'This profile name already exists. Please choose a different name.';
    }
    return null;
  }

  void _submitForm() {
    if (_formKey.currentState!.validate()) {

      String newProfileName = _nameController.text.trim();

      print('New Profile Added: $newProfileName');

      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Add Profile'),
        backgroundColor: Colors.blue,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Form(
          key: _formKey,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              TextFormField(
                controller: _nameController,
                decoration: InputDecoration(
                  labelText: 'Profile Name',
                  hintText: 'Enter a unique profile name',
                ),
                validator: _validateProfileName,
              ),
              SizedBox(height: 20),
              ElevatedButton(
                onPressed: _submitForm,
                child: Text('Save Profile'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
