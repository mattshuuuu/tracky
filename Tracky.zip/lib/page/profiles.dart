import 'package:flutter/material.dart';

// Define a model class for profiles (replace with your actual model structure)
class Profile {
  final String name;
  final String role;
  final String email;
  final String phone;
  final String location;
  final AssetImage image;

  Profile({
    required this.name,
    required this.role,
    required this.email,
    required this.phone,
    required this.location,
    required this.image,
  });
}

class ProfilesPage extends StatefulWidget {
  @override
  _ProfilesPageState createState() => _ProfilesPageState();
}

class _ProfilesPageState extends State<ProfilesPage> {
  // List of profiles (replace with your actual list of profiles)
  List<Profile> profiles = [
    Profile(
      name: 'Huh YunJin',
      role: 'Software Developer',
      email: 'yunjin@gmail.com',
      phone: '+1234567890',
      location: 'Northern Korea',
      image: AssetImage('assets/profile_image.jpg'),
    ),
    Profile(
      name: 'junkookerist',
      role: 'Software Developer',
      email: 'junkookerist@gmail.com',
      phone: '+1234567890',
      location: 'Northern Korea',
      image: AssetImage('assets/profile_image.jpg'),
    ),
  ];

  Profile? selectedProfile;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profiles'),
        centerTitle: true,
        backgroundColor: Colors.red,
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [

            if (selectedProfile != null) ...[
              CircleAvatar(
                radius: 80,
                backgroundImage: selectedProfile!.image,
              ),
              SizedBox(height: 20),
              Text(
                selectedProfile!.name,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),
              SizedBox(height: 10),
              Text(
                selectedProfile!.role,
                style: TextStyle(
                  fontSize: 18,
                  color: Colors.grey[600],
                ),
              ),
              SizedBox(height: 20),
              Divider(
                color: Colors.grey,
              ),
              SizedBox(height: 20),
              ListTile(
                leading: Icon(Icons.email),
                title: Text(selectedProfile!.email),
                onTap: () {
                  // Handle email tap if needed
                },
              ),
              ListTile(
                leading: Icon(Icons.phone),
                title: Text(selectedProfile!.phone),
                onTap: () {
                  // Handle phone
                },
              ),
              ListTile(
                leading: Icon(Icons.location_on),
                title: Text(selectedProfile!.location),
                onTap: () {
                  // Handle location
                },
              ),
            ],
            // Display list of profiles for selection
            SizedBox(height: 20),
            Text(
              'Select a Profile:',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            SizedBox(height: 10),
            Expanded(
              child: ListView.builder(
                itemCount: profiles.length,
                itemBuilder: (context, index) {
                  return ListTile(
                    title: Text(profiles[index].name),
                    onTap: () {
                      setState(() {
                        selectedProfile = profiles[index];
                      });
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
